#include "caineFaraPete.h"

void CCaineFaraPete::citire_caine_fara_pete() {
	cout << "\nIntroduceti date caine fara pete:\n" << endl;

	citire_caine();
}

void CCaineFaraPete::afisare_caine_fara_pete() {
	
	cout << "Afisare date caine fara pete:\n" << endl;

	afisare_caine();
}

