#include "caine.h"

class CCaineCuPete:public CCaine
{
protected:
	int nr_pete;
public:
	void citire_caine_pete();
	void afisare_caine_pete();
};

