#include "caineCuPete.h"

class CCaineFaraPete:public CCaine
{
public:
	void citire_caine_fara_pete();
	void afisare_caine_fara_pete();
};

